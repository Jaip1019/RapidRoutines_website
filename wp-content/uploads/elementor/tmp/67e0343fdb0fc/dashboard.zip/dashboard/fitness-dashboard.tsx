import React, { useState } from 'react';
import { 
  Menu, X, Home, MessageCircle, Activity, List, Calendar, 
  ChevronRight, ChevronLeft, BarChart2, User, Settings,
  Moon, Sun, Search
} from 'lucide-react';

// Color theme based on #1E628C
const colors = {
  primary: '#1E628C',
  secondary: '#54A0C7',
  accent: '#E67E22',
  light: '#ECF0F1',
  dark: '#2C3E50',
  success: '#2ECC71',
  warning: '#F39C12',
  danger: '#E74C3C',
  background: '#F9FAFB',
  textPrimary: '#1A202C',
  textSecondary: '#4A5568',
};

const App = () => {
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);
  const [activeView, setActiveView] = useState('dashboard');
  const [isDarkMode, setIsDarkMode] = useState(false);

  const toggleSidebar = () => {
    setIsSidebarOpen(!isSidebarOpen);
  };

  const toggleDarkMode = () => {
    setIsDarkMode(!isDarkMode);
  };

  // Dynamic background and text colors based on dark mode
  const bgColor = isDarkMode ? 'bg-gray-900' : 'bg-gray-50';
  const textColor = isDarkMode ? 'text-white' : 'text-gray-800';
  const sidebarBg = isDarkMode ? 'bg-gray-800' : 'bg-white';
  const cardBg = isDarkMode ? 'bg-gray-800' : 'bg-white';
  const borderColor = isDarkMode ? 'border-gray-700' : 'border-gray-200';

  return (
    <div className={`flex h-screen ${bgColor} ${textColor} transition-colors duration-300`}>
      {/* Sidebar */}
      <div
        className={`${sidebarBg} ${borderColor} border-r shadow-lg fixed h-full z-20 transition-all duration-300 ease-in-out ${
          isSidebarOpen ? 'w-64' : 'w-0 lg:w-20'
        }`}
      >
        <div className="flex flex-col h-full">
          {/* Sidebar Header */}
          <div className={`p-4 flex items-center justify-between ${isSidebarOpen ? '' : 'justify-center'}`}>
            {isSidebarOpen && (
              <div className="flex items-center">
                <div className="h-8 w-8 rounded-md flex items-center justify-center" style={{ backgroundColor: colors.primary }}>
                  <Activity className="h-5 w-5 text-white" />
                </div>
                <h1 className="ml-2 text-xl font-bold">FitPro</h1>
              </div>
            )}
            <button
              onClick={toggleSidebar}
              className="p-1 rounded-md hover:bg-gray-200 dark:hover:bg-gray-700 transition-colors"
            >
              {isSidebarOpen ? <ChevronLeft className="h-5 w-5" /> : <ChevronRight className="h-5 w-5" />}
            </button>
          </div>

          {/* Navigation */}
          <nav className="flex-1 overflow-y-auto py-4">
            <ul className="space-y-2 px-3">
              {[
                { id: 'dashboard', name: 'Dashboard', icon: <Home className="h-5 w-5" /> },
                { id: 'chatbot', name: 'AI Chatbot', icon: <MessageCircle className="h-5 w-5" /> },
                { id: 'repbot', name: 'Rep Counter', icon: <BarChart2 className="h-5 w-5" /> },
                { id: 'exercise-tree', name: 'Exercise Tree', icon: <List className="h-5 w-5" /> },
                { id: 'tracker', name: 'Exercise Tracker', icon: <Calendar className="h-5 w-5" /> },
              ].map((item) => (
                <li key={item.id}>
                  <button
                    onClick={() => setActiveView(item.id)}
                    className={`flex items-center w-full p-3 rounded-md transition-colors ${
                      activeView === item.id
                        ? 'bg-blue-100 text-blue-700 dark:bg-gray-700 dark:text-blue-300'
                        : 'hover:bg-gray-100 dark:hover:bg-gray-700'
                    } ${!isSidebarOpen ? 'justify-center' : ''}`}
                  >
                    <span className="flex-shrink-0">{item.icon}</span>
                    {isSidebarOpen && <span className="ml-3">{item.name}</span>}
                  </button>
                </li>
              ))}
            </ul>
          </nav>

          {/* Sidebar Footer */}
          <div className={`p-4 border-t ${borderColor}`}>
            <ul className="space-y-2">
              <li>
                <button
                  onClick={toggleDarkMode}
                  className={`flex items-center w-full p-3 rounded-md hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors ${!isSidebarOpen ? 'justify-center' : ''}`}
                >
                  <span>{isDarkMode ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}</span>
                  {isSidebarOpen && <span className="ml-3">{isDarkMode ? 'Light Mode' : 'Dark Mode'}</span>}
                </button>
              </li>
              <li>
                <button
                  className={`flex items-center w-full p-3 rounded-md hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors ${!isSidebarOpen ? 'justify-center' : ''}`}
                >
                  <span><User className="h-5 w-5" /></span>
                  {isSidebarOpen && <span className="ml-3">Profile</span>}
                </button>
              </li>
              <li>
                <button
                  className={`flex items-center w-full p-3 rounded-md hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors ${!isSidebarOpen ? 'justify-center' : ''}`}
                >
                  <span><Settings className="h-5 w-5" /></span>
                  {isSidebarOpen && <span className="ml-3">Settings</span>}
                </button>
              </li>
            </ul>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div 
        className={`flex-1 transition-all duration-300 ease-in-out ${
          isSidebarOpen ? 'ml-64' : 'ml-0 lg:ml-20'
        }`}
      >
        {/* Top Navigation Bar */}
        <header className={`${cardBg} border-b ${borderColor} sticky top-0 z-10 shadow-sm`}>
          <div className="flex items-center justify-between p-4">
            <div className="lg:hidden">
              <button
                onClick={toggleSidebar}
                className="p-2 rounded-md hover:bg-gray-200 dark:hover:bg-gray-700 transition-colors"
              >
                <Menu className="h-6 w-6" />
              </button>
            </div>
            <div className="flex-1 flex max-w-md mx-4">
              <div className="relative w-full">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <Search className="h-5 w-5 text-gray-400" />
                </div>
                <input
                  type="text"
                  className={`pl-10 pr-4 py-2 w-full rounded-md ${isDarkMode ? 'bg-gray-700 border-gray-600' : 'bg-gray-100 border-gray-300'} border focus:outline-none focus:ring-2 focus:ring-blue-500`}
                  placeholder="Search..."
                />
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <button className="relative p-2 rounded-full hover:bg-gray-200 dark:hover:bg-gray-700 transition-colors">
                <span className="absolute top-0 right-0 h-3 w-3 rounded-full bg-red-500"></span>
                <MessageCircle className="h-6 w-6" />
              </button>
              <div className="h-8 w-8 rounded-full bg-blue-500 flex items-center justify-center text-white font-semibold">
                U
              </div>
            </div>
          </div>
        </header>

        {/* Content Area */}
        <main className="p-6">
          {activeView === 'dashboard' && <DashboardView />}
          {activeView === 'chatbot' && <ChatbotView />}
          {activeView === 'repbot' && <RepCounterView />}
          {activeView === 'exercise-tree' && <ExerciseTreeView />}
          {activeView === 'tracker' && <ExerciseTrackerView />}
        </main>
      </div>
    </div>
  );
};

// Dashboard View Component
const DashboardView = () => {
  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold">Dashboard</h1>
      
      {/* Stats Section */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {[
          { title: 'Total Workouts', value: '24', change: '+12%', color: 'bg-blue-500' },
          { title: 'Active Minutes', value: '348', change: '+8%', color: 'bg-green-500' },
          { title: 'Calories Burned', value: '12,845', change: '+5%', color: 'bg-orange-500' },
          { title: 'Completed Goals', value: '8/10', change: '+2', color: 'bg-purple-500' },
        ].map((stat, index) => (
          <div key={index} className="bg-white dark:bg-gray-800 rounded-xl shadow-md overflow-hidden">
            <div className="p-5">
              <div className="flex items-center">
                <div className={`flex-shrink-0 rounded-md p-3 ${stat.color} bg-opacity-20`}>
                  <Activity className={`h-6 w-6 ${stat.color.replace('bg-', 'text-')}`} />
                </div>
                <div className="ml-5">
                  <p className="text-sm font-medium text-gray-500 dark:text-gray-400">{stat.title}</p>
                  <div className="flex items-baseline">
                    <p className="text-2xl font-semibold">{stat.value}</p>
                    <p className={`ml-2 text-sm ${stat.change.includes('+') ? 'text-green-500' : 'text-red-500'}`}>
                      {stat.change}
                    </p>
                  </div>
                </div>
              </div>
            </div>
            <div className="bg-gradient-to-r from-blue-400 to-blue-600" style={{ height: '4px' }}></div>
          </div>
        ))}
      </div>

      {/* Activity and Progress Section */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 bg-white dark:bg-gray-800 rounded-xl shadow-md p-6">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-lg font-semibold">Recent Activity</h2>
            <select className="bg-gray-100 dark:bg-gray-700 border-0 rounded-md p-2 text-sm">
              <option>This Week</option>
              <option>This Month</option>
              <option>This Year</option>
            </select>
          </div>
          
          <div className="h-64 w-full bg-gray-100 dark:bg-gray-700 rounded-lg flex items-center justify-center">
            <p className="text-gray-500 dark:text-gray-400">Activity chart will render here</p>
          </div>
        </div>

        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-md p-6">
          <h2 className="text-lg font-semibold mb-6">Progress Goals</h2>
          
          <div className="space-y-6">
            {[
              { name: 'Weekly Workouts', progress: 75, target: '5/7' },
              { name: 'Weight Goal', progress: 60, target: '160 lbs' },
              { name: 'Active Minutes', progress: 45, target: '150 min' },
            ].map((goal, index) => (
              <div key={index} className="space-y-2">
                <div className="flex justify-between items-center">
                  <p className="text-sm font-medium">{goal.name}</p>
                  <p className="text-sm text-gray-500 dark:text-gray-400">{goal.target}</p>
                </div>
                <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2.5">
                  <div 
                    className="bg-blue-600 h-2.5 rounded-full" 
                    style={{ width: `${goal.progress}%` }}
                  ></div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Upcoming and Recent Exercise Section */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-md p-6">
          <h2 className="text-lg font-semibold mb-6">Upcoming Workouts</h2>
          
          <div className="space-y-4">
            {[
              { name: 'Upper Body', time: 'Today, 6:00 PM', duration: '45 min' },
              { name: 'Cardio Session', time: 'Tomorrow, 7:30 AM', duration: '30 min' },
              { name: 'Leg Day', time: 'Wed, 6:00 PM', duration: '60 min' },
            ].map((workout, index) => (
              <div key={index} className="flex items-center p-3 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors">
                <div className="bg-blue-100 dark:bg-blue-900 p-3 rounded-full">
                  <Activity className="h-5 w-5 text-blue-500 dark:text-blue-300" />
                </div>
                <div className="ml-4 flex-1">
                  <p className="font-medium">{workout.name}</p>
                  <p className="text-sm text-gray-500 dark:text-gray-400">{workout.time}</p>
                </div>
                <div className="bg-gray-100 dark:bg-gray-700 px-3 py-1 rounded-full text-sm">
                  {workout.duration}
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-md p-6">
          <h2 className="text-lg font-semibold mb-6">Recent Exercises</h2>
          
          <div className="space-y-4">
            {[
              { name: 'Bench Press', sets: '3 sets', weight: '185 lbs' },
              { name: 'Deadlift', sets: '4 sets', weight: '225 lbs' },
              { name: 'Squats', sets: '3 sets', weight: '205 lbs' },
              { name: 'Pull-ups', sets: '3 sets', weight: 'Body weight' },
            ].map((exercise, index) => (
              <div key={index} className="flex items-center p-3 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors">
                <div className="flex-1">
                  <p className="font-medium">{exercise.name}</p>
                  <p className="text-sm text-gray-500 dark:text-gray-400">{exercise.sets}</p>
                </div>
                <div className="bg-gray-100 dark:bg-gray-700 px-3 py-1 rounded-full text-sm">
                  {exercise.weight}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

// Chatbot View Component
const ChatbotView = () => {
  const [messages, setMessages] = useState([
    { sender: 'bot', text: 'Hi there! I\'m your fitness assistant. How can I help you today?' },
    { sender: 'user', text: 'Can you recommend a good warm-up routine?' },
    { sender: 'bot', text: 'Absolutely! I recommend starting with 5 minutes of light cardio like jogging in place or jumping jacks, followed by dynamic stretches such as arm circles, hip rotations, and leg swings. Finish with some bodyweight movements like 10 squats and 10 push-ups to activate your muscles.' },
  ]);

  const [newMessage, setNewMessage] = useState('');

  const sendMessage = () => {
    if (newMessage.trim() === '') return;
    
    // Add user message
    setMessages([...messages, { sender: 'user', text: newMessage }]);
    
    // Simulate bot response
    setTimeout(() => {
      setMessages(prev => [...prev, { 
        sender: 'bot', 
        text: 'I\'m processing your question. In a real implementation, this would connect to a backend service for more intelligent responses.' 
      }]);
    }, 1000);
    
    setNewMessage('');
  };

  return (
    <div className="h-full flex flex-col space-y-6">
      <h1 className="text-2xl font-bold">AI Fitness Chatbot</h1>
      
      <div className="flex-1 bg-white dark:bg-gray-800 rounded-xl shadow-md flex flex-col">
        {/* Chat Messages */}
        <div className="flex-1 p-4 overflow-y-auto">
          <div className="space-y-4">
            {messages.map((message, index) => (
              <div 
                key={index} 
                className={`flex ${message.sender === 'user' ? 'justify-end' : 'justify-start'}`}
              >
                <div 
                  className={`max-w-xs md:max-w-md lg:max-w-lg px-4 py-2 rounded-lg ${
                    message.sender === 'user' 
                      ? 'bg-blue-500 text-white' 
                      : 'bg-gray-200 dark:bg-gray-700'
                  }`}
                >
                  {message.text}
                </div>
              </div>
            ))}
          </div>
        </div>
        
        {/* Chat Input */}
        <div className="p-4 border-t dark:border-gray-700">
          <div className="flex items-center">
            <input
              type="text"
              className="flex-1 bg-gray-100 dark:bg-gray-700 border-0 rounded-l-lg p-3 focus:outline-none focus:ring-2 focus:ring-blue-500"
              placeholder="Ask about exercises, nutrition, or fitness goals..."
              value={newMessage}
              onChange={(e) => setNewMessage(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && sendMessage()}
            />
            <button
              className="bg-blue-500 hover:bg-blue-600 text-white rounded-r-lg px-4 py-3 transition-colors"
              onClick={sendMessage}
            >
              Send
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

// Rep Counter View Component
const RepCounterView = () => {
  const [count, setCount] = useState(0);
  const [exercise, setExercise] = useState('Push-ups');
  const [goal, setGoal] = useState(20);
  const [history, setHistory] = useState([
    { exercise: 'Squats', count: 15, date: 'Today, 10:30 AM' },
    { exercise: 'Pull-ups', count: 12, date: 'Yesterday, 4:15 PM' }
  ]);

  const incrementCount = () => {
    setCount(count + 1);
  };

  const resetCount = () => {
    // Save to history
    if (count > 0) {
      setHistory([
        { 
          exercise, 
          count, 
          date: new Date().toLocaleString('en-US', { 
            hour: 'numeric', 
            minute: 'numeric', 
            hour12: true,
            weekday: 'short'
          })
        },
        ...history
      ]);
    }
    setCount(0);
  };

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold">Rep Counter</h1>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 bg-white dark:bg-gray-800 rounded-xl shadow-md p-6 flex flex-col items-center justify-center">
          <div className="w-full flex justify-between mb-6">
            <div>
              <p className="text-gray-500 dark:text-gray-400">Exercise</p>
              <select 
                className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm rounded-md dark:bg-gray-700 dark:border-gray-600"
                value={exercise}
                onChange={(e) => setExercise(e.target.value)}
              >
                <option>Push-ups</option>
                <option>Pull-ups</option>
                <option>Squats</option>
                <option>Lunges</option>
                <option>Planks</option>
              </select>
            </div>
            <div>
              <p className="text-gray-500 dark:text-gray-400">Goal</p>
              <input 
                type="number" 
                className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm rounded-md dark:bg-gray-700 dark:border-gray-600"
                value={goal}
                onChange={(e) => setGoal(Number(e.target.value))}
                min="1"
              />
            </div>
          </div>
          
          <div className="text-center mb-8">
            <div className="relative mb-4">
              <div className="text-8xl font-bold">{count}</div>
              <div className="text-lg text-gray-500 dark:text-gray-400">/ {goal}</div>
              
              {/* Progress circle (simplified) */}
              <div className="absolute inset-0 flex items-center justify-center -z-10">
                <div className="h-48 w-48 rounded-full border-8 border-gray-200 dark:border-gray-700"></div>
                <div 
                  className="absolute h-48 w-48 rounded-full border-8 border-blue-500"
                  style={{
                    clipPath: `polygon(50% 50%, 50% 0%, ${50 + 50 * Math.sin(2 * Math.PI * Math.min(count / goal, 1))}% ${50 - 50 * Math.cos(2 * Math.PI * Math.min(count / goal, 1))}%, 50% 0%)`
                  }}
                ></div>
              </div>
            </div>
            
            <p className="mb-4 text-xl">{exercise}</p>
            
            <div className="flex space-x-4">
              <button 
                className="bg-blue-500 hover:bg-blue-600 text-white font-bold py-4 px-6 rounded-lg text-xl transition-colors flex-1"
                onClick={incrementCount}
              >
                Count Rep
              </button>
              <button 
                className="bg-gray-200 dark:bg-gray-700 hover:bg-gray-300 dark:hover:bg-gray-600 font-bold py-4 px-4 rounded-lg transition-colors"
                onClick={resetCount}
              >
                Reset
              </button>
            </div>
          </div>
        </div>
        
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-md p-6">
          <h2 className="text-lg font-semibold mb-4">Recent History</h2>
          
          <div className="space-y-4">
            {history.map((item, index) => (
              <div key={index} className="p-3 border-b dark:border-gray-700 last:border-0">
                <div className="flex justify-between items-center">
                  <p className="font-medium">{item.exercise}</p>
                  <p className="text-sm text-gray-500 dark:text-gray-400">{item.date}</p>
                </div>
                <p className="text-2xl font-bold mt-1">{item.count} reps</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

// Exercise Tree View Component
const ExerciseTreeView = () => {
  const exerciseCategories = [
    {
      name: 'Upper Body',
      icon: '💪',
      exercises: [
        { name: 'Bench Press', muscles: 'Chest, Triceps', difficulty: 'Intermediate' },
        { name: 'Pull-ups', muscles: 'Back, Biceps', difficulty: 'Advanced' },
        { name: 'Shoulder Press', muscles: 'Shoulders, Triceps', difficulty: 'Intermediate' },
        { name: 'Bicep Curls', muscles: 'Biceps', difficulty: 'Beginner' },
      ]
    },
    {
      name: 'Lower Body',
      icon: '🦵',
      exercises: [
        { name: 'Squats', muscles: 'Quads, Glutes', difficulty: 'Intermediate' },
        { name: 'Deadlifts', muscles: 'Hamstrings, Back, Glutes', difficulty: 'Advanced' },
        { name: 'Lunges', muscles: 'Quads, Glutes', difficulty: 'Beginner' },
        { name: 'Calf Raises', muscles: 'Calves', difficulty: 'Beginner' },
      ]
    },
    {
      name: 'Core',
      icon: '🧘',
      exercises: [
        { name: 'Plank', muscles: 'Core, Shoulders', difficulty: 'Beginner' },
        { name: 'Russian Twists', muscles: 'Obliques', difficulty: 'Intermediate' },
        { name: 'Leg Raises', muscles: 'Lower Abs', difficulty: 'Intermediate' },
        { name: 'Mountain Climbers', muscles: 'Core, Shoulders', difficulty: 'Beginner' },
      ]
    },
    {
      name: 'Cardio',
      icon: '🏃',
      exercises: [
        { name: 'Running', muscles: 'Full Body', difficulty: 'Variable' },
        { name: 'Jumping Jacks', muscles: 'Full Body', difficulty: 'Beginner' },
        { name: 'Burpees', muscles: 'Full Body', difficulty: 'Advanced' },
        { name: 'Jump Rope', muscles: 'Full Body', difficulty: 'Intermediate' },
      ]
    },
  ];

  const [activeCategory, setActiveCategory] = useState('Upper Body');
  const [searchTerm, setSearchTerm] = useState('');

  const filteredExercises = exerciseCategories
    .flatMap(category => category.exercises.map(exercise => ({
      ...exercise,
      category: category.name
    })))
    .filter(exercise => 
      exercise.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      exercise.muscles.toLowerCase().includes(searchTerm.toLowerCase()) ||
      exercise.category.toLowerCase().includes(searchTerm.toLowerCase())
    );

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold">Exercise Tree</h1>
      
      <div className="relative w-full max-w-md mb-6">
        <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
          <Search className="h-5 w-5 text-gray-400" />
        </div>
        <input
          type="text"
          className="pl-10 pr-4 py-2 w-full rounded-md bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-700 focus:outline-none focus:ring-2 focus:ring-blue-500"
          placeholder="Search exercises..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
        />
      </div>
      
      {searchTerm ? (
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-md p-6">
          <h2 className="text-lg font-semibold mb-4">Search Results</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {filteredExercises.map((exercise, index) => (
              <div key={index} className="border dark:border-gray-700 rounded-lg p-4 hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors">
                <p className="font-medium">{exercise.name}</p>
                <p className="text-sm text-gray-500 dark:text-gray-400">Category: {exercise.category}</p>
                <p className="text-sm text-gray-500 dark:text-gray-400">Muscles: {exercise.muscles}</p>
                <div className={`mt-2 inline-block px-2 py-1 text-xs rounded-full ${
                  exercise.difficulty === 'Beginner' ? 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200' :
                  exercise.difficulty === 'Intermediate' ? 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200' :
                  'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200'
                }`}>
                  {exercise.difficulty}
                </div>
              </div>
            ))}
          </div>
        </div>
      ) : (
        <>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            {exerciseCategories.map((category) => (
              <button
                key={category.name}
                className={`p-4 rounded-xl shadow-md flex flex-col items-center transition-colors ${
                  activeCategory === category.name 
                    ? 'bg-blue-100 dark:bg-blue-900' 
                    : 'bg-white dark:bg-gray-800 hover:bg-gray-50 dark:hover:bg-gray-700'
                }`}
                onClick={() => setActiveCategory(category.name)}
              >
                <span className="text-4xl mb-2">{category.icon}</span>
                <span className="font-medium">{category.name}</span>
              </button>
            ))}
          </div>
          
          <div className="bg-white dark:bg-gray-800 rounded-xl shadow-md p-6">
            <h2 className="text-lg font-semibold mb-4">
              {activeCategory} Exercises
            </h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {exerciseCategories
                .find(category => category.name === activeCategory)
                ?.exercises.map((exercise, index) => (
                  <div key={index} className="border dark:border-gray-700 rounded-lg p-4 hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors">
                    <p className="font-medium">{exercise.name}</p>
                    <p className="text-sm text-gray-500 dark:text-gray-400">Muscles: {exercise.muscles}</p>
                    <div className={`mt-2 inline-block px-2 py-1 text-xs rounded-full ${
                      exercise.difficulty === 'Beginner' ? 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200' :
                      exercise.difficulty === 'Intermediate' ? 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200' :
                      'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200'
                    }`}>
                      {exercise.difficulty}
                    </div>
                  </div>
                ))
              }
            </div>
          </div>
        </>
      )}
    </div>
  );
};

// Exercise Tracker View Component
const ExerciseTrackerView = () => {
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [workouts, setWorkouts] = useState([
    { 
      date: new Date().toISOString().split('T')[0], 
      exercises: [
        { name: 'Bench Press', sets: 3, reps: 10, weight: 155 },
        { name: 'Squats', sets: 4, reps: 8, weight: 185 },
      ]
    },
    { 
      date: new Date(Date.now() - 86400000 * 2).toISOString().split('T')[0], 
      exercises: [
        { name: 'Pull-ups', sets: 3, reps: 8, weight: 0 },
        { name: 'Deadlift', sets: 3, reps: 6, weight: 225 },
      ]
    },
  ]);

  const selectedWorkout = workouts.find(workout => 
    workout.date === selectedDate.toISOString().split('T')[0]
  );

  // Days with workouts (for calendar highlights)
  const workoutDays = workouts.map(workout => workout.date);

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold">Exercise Tracker</h1>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-md p-6">
          <h2 className="text-lg font-semibold mb-4">Calendar</h2>
          
          <div className="flex justify-between items-center mb-4">
            <button className="p-2 rounded-full hover:bg-gray-100 dark:hover:bg-gray-700">
              <ChevronLeft className="h-5 w-5" />
            </button>
            <h3 className="font-medium">
              {selectedDate.toLocaleString('default', { month: 'long', year: 'numeric' })}
            </h3>
            <button className="p-2 rounded-full hover:bg-gray-100 dark:hover:bg-gray-700">
              <ChevronRight className="h-5 w-5" />
            </button>
          </div>
          
          <div className="grid grid-cols-7 gap-2 text-center">
            {['S', 'M', 'T', 'W', 'T', 'F', 'S'].map((day, index) => (
              <div key={`header-${index}`} className="text-gray-500 dark:text-gray-400 text-sm py-2">
                {day}
              </div>
            ))}
            
            {/* Placeholder for days in month */}
            {Array.from({ length: 31 }, (_, i) => i + 1).map(day => {
              const date = new Date(selectedDate.getFullYear(), selectedDate.getMonth(), day);
              const dateString = date.toISOString().split('T')[0];
              const isCurrentMonth = date.getMonth() === selectedDate.getMonth();
              const isSelected = date.toDateString() === selectedDate.toDateString();
              const hasWorkout = workoutDays.includes(dateString);
              
              if (!isCurrentMonth) return null;
              
              return (
                <button 
                  key={`day-${day}`}
                  className={`aspect-square py-2 rounded-full text-sm ${
                    isSelected 
                      ? 'bg-blue-500 text-white' 
                      : hasWorkout 
                        ? 'bg-blue-100 dark:bg-blue-900' 
                        : 'hover:bg-gray-100 dark:hover:bg-gray-700'
                  }`}
                  onClick={() => setSelectedDate(date)}
                >
                  {day}
                </button>
              );
            })}
          </div>
        </div>
        
        <div className="lg:col-span-2 bg-white dark:bg-gray-800 rounded-xl shadow-md p-6">
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-lg font-semibold">
              Workout for {selectedDate.toLocaleDateString('en-US', { 
                weekday: 'long', 
                month: 'short', 
                day: 'numeric' 
              })}
            </h2>
            <button className="bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded-md transition-colors">
              Add Exercise
            </button>
          </div>
          
          {selectedWorkout ? (
            <div className="space-y-4">
              {selectedWorkout.exercises.map((exercise, index) => (
                <div key={index} className="border dark:border-gray-700 rounded-lg p-4">
                  <div className="flex justify-between items-center mb-2">
                    <h3 className="font-medium">{exercise.name}</h3>
                    <div className="flex space-x-2">
                      <button className="text-blue-500 hover:text-blue-600">Edit</button>
                      <button className="text-red-500 hover:text-red-600">Delete</button>
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-3 gap-4 text-center">
                    <div>
                      <p className="text-gray-500 dark:text-gray-400 text-sm">Sets</p>
                      <p className="font-medium">{exercise.sets}</p>
                    </div>
                    <div>
                      <p className="text-gray-500 dark:text-gray-400 text-sm">Reps</p>
                      <p className="font-medium">{exercise.reps}</p>
                    </div>
                    <div>
                      <p className="text-gray-500 dark:text-gray-400 text-sm">Weight</p>
                      <p className="font-medium">{exercise.weight} lbs</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center py-12">
              <div className="bg-gray-100 dark:bg-gray-700 p-4 rounded-full mb-4">
                <Calendar className="h-8 w-8 text-gray-500 dark:text-gray-400" />
              </div>
              <p className="text-lg font-medium mb-2">No workout logged for this day</p>
              <p className="text-gray-500 dark:text-gray-400 mb-4 text-center">
                Start tracking your fitness progress by adding exercises to your workout
              </p>
              <button className="bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded-md transition-colors">
                Log a Workout
              </button>
            </div>
          )}
        </div>
      </div>
      
      <div className="bg-white dark:bg-gray-800 rounded-xl shadow-md p-6">
        <h2 className="text-lg font-semibold mb-4">Recent Progress</h2>
        
        <div className="h-64 w-full bg-gray-100 dark:bg-gray-700 rounded-lg flex items-center justify-center">
          <p className="text-gray-500 dark:text-gray-400">Progress chart will render here</p>
        </div>
      </div>
    </div>
  );
};

export default App;